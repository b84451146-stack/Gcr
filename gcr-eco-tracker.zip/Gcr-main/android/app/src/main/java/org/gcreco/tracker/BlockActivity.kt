package org.gcreco.tracker

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** Shown on top of an AI app once the daily limit is used up. */
class BlockActivity : AppCompatActivity() {

    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#FFFDF6E3"))
            setPadding(64, 64, 64, 64)
        }
        val title = TextView(this).apply {
            text = "AI limit reached"
            textSize = 26f
            setTextColor(Color.parseColor("#FF222222"))
            gravity = Gravity.CENTER
        }
        info = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#FF222222"))
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 48)
        }
        val quiz = Button(this).apply {
            text = "Take a quiz (+${TimeLimit.QUIZ_BONUS_MIN} min)"
            setOnClickListener {
                startActivity(
                    Intent(this@BlockActivity, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        .putExtra("start_quiz", true)
                )
                finish()
            }
        }
        val home = Button(this).apply {
            text = "Go to home screen"
            setOnClickListener { goHome() }
        }
        box.addView(title)
        box.addView(info)
        box.addView(quiz)
        box.addView(home)
        setContentView(box)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goHome() }
        })
    }

    override fun onResume() {
        super.onResume()
        val c = this
        if (!TimeLimit.isLimitReached(c)) { finish(); return }
        info.text = "You have used ${TimeLimit.fmt(TimeLimit.usedSeconds(c))} of " +
            "${TimeLimit.fmt(TimeLimit.limitSeconds(c))} today.\n\n" +
            "The limit resets at midnight. Answer a quiz correctly to earn " +
            "+${TimeLimit.QUIZ_BONUS_MIN} minutes."
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
