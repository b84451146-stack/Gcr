package org.gcreco.tracker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Watches which app is in the foreground. When a supported AI app is open and today's limit is
 * used up, it opens BlockActivity on top. Needs Usage Access + "Display over other apps".
 */
class BlockerService : Service() {

    private var executor: ScheduledExecutorService? = null
    private var lastQuery = 0L
    private var foreground: String? = null
    private var lastBlock = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (executor == null) {
            executor = Executors.newSingleThreadScheduledExecutor().also {
                it.scheduleWithFixedDelay({
                    try { tick() } catch (_: Exception) { }
                }, 0, 1500, TimeUnit.MILLISECONDS)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        executor?.shutdownNow()
        executor = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "AI time limit", NotificationManager.IMPORTANCE_MIN)
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("GCR Eco is watching your AI time")
            .setContentText("Daily limit applies to AI apps")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun tick() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - 10 * 60 * 1000 else lastQuery - 2000
        lastQuery = now

        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> foreground = pkg
                UsageEvents.Event.ACTIVITY_PAUSED,
                UsageEvents.Event.ACTIVITY_STOPPED -> if (foreground == pkg) foreground = null
            }
        }

        val fg = foreground ?: return
        if (!AiApps.isSupported(fg)) return
        if (now - lastBlock < 3000) return
        if (!TimeLimit.isLimitReached(this)) return

        lastBlock = now
        if (Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(this, BlockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("pkg", fg)
            )
        }
    }

    companion object {
        private const val CHANNEL = "gcr_limit"
        private const val NOTIF_ID = 4101
    }
}
