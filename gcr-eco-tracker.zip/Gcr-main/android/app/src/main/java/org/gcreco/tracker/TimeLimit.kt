package org.gcreco.tracker

import android.content.Context
import java.time.LocalDate

/**
 * Daily AI-time limit.
 *  - Base limit: 3 hours across all supported AI apps combined.
 *  - Each correct quiz answer that earns a reward adds +30 minutes (the quiz already caps at
 *    3 rewards per day, so the most you can reach is 3h + 90 min).
 *  - Everything resets automatically when the phone's local date changes. Nothing to turn on.
 */
object TimeLimit {
    const val BASE_MIN = 180
    const val QUIZ_BONUS_MIN = 30

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("gcr_limit", Context.MODE_PRIVATE)

    private fun rollover(c: Context) {
        val today = LocalDate.now().toString()
        val s = sp(c)
        if (s.getString("day", "") != today) {
            s.edit().putString("day", today).putInt("bonusMin", 0).apply()
        }
    }

    fun bonusMin(c: Context): Int { rollover(c); return sp(c).getInt("bonusMin", 0) }

    fun addQuizBonus(c: Context) {
        rollover(c)
        val s = sp(c)
        s.edit().putInt("bonusMin", s.getInt("bonusMin", 0) + QUIZ_BONUS_MIN).apply()
    }

    fun limitSeconds(c: Context): Long = (BASE_MIN + bonusMin(c)) * 60L

    fun usedSeconds(c: Context): Long =
        UsageReader(c).secondsForDay(LocalDate.now()).values.sum()

    fun remainingSeconds(c: Context): Long =
        (limitSeconds(c) - usedSeconds(c)).coerceAtLeast(0L)

    fun isLimitReached(c: Context): Boolean = usedSeconds(c) >= limitSeconds(c)

    fun fmt(seconds: Long): String {
        val m = seconds / 60
        return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
    }
}
